# Crypto Trading Simulator
This project is not complete yet, this is part of my *[How to  Build a Simple Crypto Trading Simulator](https://hackernoon.com/how-to-build-a-simple-crypto-trading-simulator-part-1-4ccdddcd6b76)* Series. The idea is to help beginneer investor learn and experiment without losing real money.

You need to download the database from [here](https://drive.google.com/open?id=1OHhtrvOe-EWcX_8tipWo6tWYqkkYDkPw) and place it in the project folder.

**In the coming days I will be adding functionalities to monitor live prices, write and test strategies and design a great user interface. I will need your support to do that, you can support me by [buying me a coffee](http://buymeacoffee.com/febin).
If I get enough support, I will even build a mobile app and publish it for free.**

![Screenshot](/screenshot.png)
